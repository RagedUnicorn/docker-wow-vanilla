
Windows
Download SDL Developer Libraries from http://www.libsdl.org and unzip them to SDL/

OSX
Download and install OSX SDL Developer Libraries from http://www.libsdl.org